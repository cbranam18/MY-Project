#Caleb Branam- Lesson 1-01


#1- I was pretty comfortable with everything in this lesson. I didn't know you could 
#   change the colors of R. That will be very helpful.

#2- Nothing confuses me about this first lesson

#3- I can't think of anything else that isn't in this lesson. I have had classes
#   using R before. However, it has been roughly 3 years since I've really used it
#   and this is helping me get used to the program again and teach me more advanced
#   topics that I might not have covered much or have forgotten since undergrad.
#   During my undergraduate career I took quantitative ecology, population ecology,
#   and fish population dynamics that all incorporated and taught us R, but I 
#   haven't had an R specific class like this before.